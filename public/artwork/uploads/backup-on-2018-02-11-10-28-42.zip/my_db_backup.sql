#
# TABLE STRUCTURE FOR: ci_sessions
#

DROP TABLE IF EXISTS ci_sessions;

CREATE TABLE `ci_sessions` (
  `session_id` varchar(40) NOT NULL DEFAULT '0',
  `ip_address` varchar(16) NOT NULL DEFAULT '0',
  `user_agent` varchar(50) NOT NULL DEFAULT '',
  `last_activity` int(10) unsigned NOT NULL DEFAULT '0',
  `user_data` text NOT NULL,
  PRIMARY KEY (`session_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('7f494d757cc4935e500d8df74c445902', '107.77.68.49', 'Mozilla/5.0 (iPhone; CPU iPhone OS 11_2_5 like Mac', 1518230458, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('766058e961b76031501de72c82b038d3', '107.77.68.49', 'Mozilla/5.0 (iPhone; CPU iPhone OS 11_2_5 like Mac', 1518230449, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('36cf97df9081a2da5ee5dea8e615d39e', '107.77.68.49', 'Mozilla/5.0 (iPhone; CPU iPhone OS 11_2_5 like Mac', 1518230430, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('810576fd07e060deadf39c3cbca75391', '107.77.68.49', 'Mozilla/5.0 (iPhone; CPU iPhone OS 11_2_5 like Mac', 1518230388, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('c8f233db15693d9ec1a70b1a5d1c0c9a', '107.77.68.49', 'Mozilla/5.0 (iPhone; CPU iPhone OS 11_2_5 like Mac', 1518230400, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('6c0ad2c26ea6e22fdca962fa4ae09586', '107.77.68.49', 'Mozilla/5.0 (iPhone; CPU iPhone OS 11_2_5 like Mac', 1518230381, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('c91ada17ea376cfbf5fe795f28858cdf', '107.77.68.49', 'Mozilla/5.0 (iPhone; CPU iPhone OS 11_2_5 like Mac', 1518230376, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('693508c1c77b982cea28d2b82e4d9190', '107.77.68.49', 'Mozilla/5.0 (iPhone; CPU iPhone OS 11_2_5 like Mac', 1518230372, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('27bf1bf566706aa0f20ac7164cc7ed72', '107.77.68.49', 'Mozilla/5.0 (iPhone; CPU iPhone OS 11_2_5 like Mac', 1518230357, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('ed5d1dc835a99933e8fd6379e1fc3d5f', '107.77.68.49', 'Mozilla/5.0 (iPhone; CPU iPhone OS 11_2_5 like Mac', 1518230240, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('a8b345772e71cdd67fa3138c88c47e60', '107.77.68.49', 'Mozilla/5.0 (iPhone; CPU iPhone OS 11_2_5 like Mac', 1518230168, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('078231808e1ed232acbb47de137f9468', '107.77.68.49', 'Mozilla/5.0 (iPhone; CPU iPhone OS 11_2_5 like Mac', 1518230113, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('b237a2c7ff1da39c7eb7e6059706a7c5', '107.77.68.49', 'Mozilla/5.0 (iPhone; CPU iPhone OS 11_2_5 like Mac', 1518230094, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('bc8f3a133e777b79425795a9bec93582', '107.77.68.49', 'Mozilla/5.0 (iPhone; CPU iPhone OS 11_2_5 like Mac', 1518230019, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('30c8346fa3939c1c76ae1bc77afaf3a2', '107.77.68.49', 'Mozilla/5.0 (iPhone; CPU iPhone OS 11_2_5 like Mac', 1518230007, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('c989362ee2d6ed67a3cb53472ce27c62', '107.77.68.49', 'Mozilla/5.0 (iPhone; CPU iPhone OS 11_2_5 like Mac', 1518230003, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('5fe8d45eec3f439ad7de91dc7af30dd0', '107.77.68.49', 'Mozilla/5.0 (iPhone; CPU iPhone OS 11_2_5 like Mac', 1518229999, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('27a95076d5711994eb7aad0c450ddb33', '107.77.68.49', 'Mozilla/5.0 (iPhone; CPU iPhone OS 11_2_5 like Mac', 1518229996, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('baf755ef8d24824b87c8368d096961dd', '216.244.66.199', 'Mozilla/5.0 (compatible; DotBot/1.1; http://www.op', 1518253050, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('09e2f589d3be2b29fbc01c55288cc183', '189.177.241.202', 'Mozilla/5.0 (iPhone; CPU iPhone OS 11_2_5 like Mac', 1518229417, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('371478c6e60d0ad5b66c34218be1322d', '189.177.241.202', 'Mozilla/5.0 (iPhone; CPU iPhone OS 11_2_5 like Mac', 1518229427, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('762a4b2c9b68c2d9e4587a66de037bfe', '189.177.241.202', 'Mozilla/5.0 (iPhone; CPU iPhone OS 11_2_5 like Mac', 1518229466, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('b55e76e2d833f5fc9257341c85b0d567', '189.177.241.202', 'Mozilla/5.0 (iPhone; CPU iPhone OS 11_2_5 like Mac', 1518229558, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('dcac0f566adf68c08fe242e5d8a74c42', '189.177.241.202', 'Mozilla/5.0 (iPhone; CPU iPhone OS 11_2_5 like Mac', 1518229563, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('5a2d6eac6819386732f1bf62fe49dcee', '189.177.241.202', 'Mozilla/5.0 (iPhone; CPU iPhone OS 11_2_5 like Mac', 1518229579, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('8b5af60fff369c39b5eea303930f24b6', '189.177.241.202', 'Mozilla/5.0 (iPhone; CPU iPhone OS 11_2_5 like Mac', 1518229653, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('0fcdefe31984dce78414cee338c5dff6', '189.177.241.202', 'Mozilla/5.0 (iPhone; CPU iPhone OS 11_2_5 like Mac', 1518229654, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('954bb98d1725ec7c731136a26e33565e', '107.77.68.49', 'Mozilla/5.0 (iPhone; CPU iPhone OS 11_2_5 like Mac', 1518229695, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('7107dd26af0db1fe5db870a15351c2ad', '107.77.68.49', 'Mozilla/5.0 (iPhone; CPU iPhone OS 11_2_5 like Mac', 1518229716, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('2d21189d5b1670faa07fc3fb3a0c21ff', '107.77.68.49', 'Mozilla/5.0 (iPhone; CPU iPhone OS 11_2_5 like Mac', 1518229764, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('695f5b0c8b97f25b51a3a15664e53a60', '107.77.68.49', 'Mozilla/5.0 (iPhone; CPU iPhone OS 11_2_5 like Mac', 1518229779, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('743f59cd2618bf86d3dde12b7c3096df', '107.77.68.49', 'Mozilla/5.0 (iPhone; CPU iPhone OS 11_2_5 like Mac', 1518229883, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('4b636655d69429fd012fbd866bcec496', '107.77.68.49', 'Mozilla/5.0 (iPhone; CPU iPhone OS 11_2_5 like Mac', 1518229938, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('79e9d178daabb4e6f7aa7b341efd0bf3', '189.177.241.202', 'WhatsApp/2.18.21 i', 1518229970, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('b0f2a20aa4364fc0852c9d945923117c', '107.77.68.49', 'Mozilla/5.0 (iPhone; CPU iPhone OS 11_2_5 like Mac', 1518229992, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('7690d790e70e23cdfa74cfb4906f47fb', '107.77.68.49', 'Mozilla/5.0 (iPhone; CPU iPhone OS 11_2_5 like Mac', 1518230477, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('9c1aa6d50767c82a996f4e447d5f9182', '107.77.68.49', 'Mozilla/5.0 (iPhone; CPU iPhone OS 11_2_5 like Mac', 1518230489, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('e167fda41b6a1a2e8cee029df9967772', '107.77.68.49', 'Mozilla/5.0 (iPhone; CPU iPhone OS 11_2_5 like Mac', 1518230500, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('ca9b582c33ae86adf2e2e7d29f8a9c5c', '107.77.68.49', 'Mozilla/5.0 (iPhone; CPU iPhone OS 11_2_5 like Mac', 1518230509, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('09c2826a36e735eac5a95deb7912a4c4', '107.77.68.49', 'Mozilla/5.0 (iPhone; CPU iPhone OS 11_2_5 like Mac', 1518230525, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('864727a644b9a57210be987dd56e6c47', '107.77.68.82', 'Mozilla/5.0 (iPhone; CPU iPhone OS 11_2_5 like Mac', 1518230545, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('cbbc47f8d7ac5c431e4502ed841dd233', '189.177.241.202', 'Mozilla/5.0 (iPhone; CPU iPhone OS 11_2_5 like Mac', 1518230564, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('6cca40b4f142547d8ccb0f561cc30e6b', '189.177.241.202', 'Mozilla/5.0 (iPhone; CPU iPhone OS 11_2_5 like Mac', 1518230616, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('c9448a9869e68b7dbf3e14196afa5fd4', '189.177.241.202', 'Mozilla/5.0 (iPhone; CPU iPhone OS 11_2_5 like Mac', 1518230655, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('ab94f245575e589d6d8bd388a7997cdb', '189.177.241.202', 'Mozilla/5.0 (iPhone; CPU iPhone OS 11_2_5 like Mac', 1518230679, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('df25f3eaf8bf4f34bbcb829023081928', '189.177.241.202', 'Mozilla/5.0 (iPhone; CPU iPhone OS 11_2_5 like Mac', 1518230702, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('705f8336dc719ae3e9bd8406d94828c6', '189.177.241.202', 'Mozilla/5.0 (iPhone; CPU iPhone OS 11_2_5 like Mac', 1518230717, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('4e168b35abca54ab16e4e3169f64fd23', '189.177.241.202', 'Mozilla/5.0 (iPhone; CPU iPhone OS 11_2_5 like Mac', 1518230723, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('014786936537ab4b6b84f6f19fa3e017', '42.236.10.103', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_2) App', 1518233077, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('9bc061d74af8040f0cd256d21c0240ac', '42.236.10.103', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (K', 1518233082, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('fdc3c902c2b9a077e6cebc6ea81cddb3', '180.76.15.25', 'Mozilla/5.0 (compatible; Baiduspider/2.0; +http://', 1518235191, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('c60d98f89b4140f4eea88629177faf29', '207.46.13.156', 'Mozilla/5.0 (iPhone; CPU iPhone OS 7_0 like Mac OS', 1518272229, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('4e36bc78e82336f56da07aa3bb4111e7', '180.76.15.13', 'Mozilla/5.0 (compatible; Baiduspider/2.0; +http://', 1518273531, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('472a6ae884edcef273f7ae4665e1442a', '216.244.66.199', 'Mozilla/5.0 (compatible; DotBot/1.1; http://www.op', 1518275281, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('91fac354a86304db9d0f02049b0968f6', '187.254.154.35', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:58.0)', 1518276900, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('25791d1572b93ae14968f12e9da25e76', '187.254.148.197', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:58.0)', 1518278990, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('c7598dfa78610d5d2453c702eeea5e04', '187.254.154.35', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:58.0)', 1518280531, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('5142939dbd9637f8e7d09f1f3e07118e', '187.254.154.35', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:58.0)', 1518280534, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('c9c2f29d568f1634a5401d9e0047b278', '187.254.154.35', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:58.0)', 1518280541, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('2e6bcf332663513099d1d89e40aa1ed0', '187.254.154.35', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:58.0)', 1518280544, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('ae6ddd9d4aa259e57989765cddb45e1e', '66.249.65.138', 'Mozilla/5.0 (Linux; Android 6.0.1; Nexus 5X Build/', 1518281305, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('4308a2101246fca19566254a5938454c', '13.56.229.65', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) Ap', 1518283102, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('d311731304a7c83e478531ed3cb53fd9', '5.255.250.182', 'Mozilla/5.0 (compatible; YandexBot/3.0; +http://ya', 1518284316, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('75e6016248a3cc489c88ef9ee3acff5a', '17.142.154.178', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) Ap', 1518291724, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('cb7bd0cc3cb31df67351eed791eb7f39', '180.76.15.23', 'Mozilla/5.0 (compatible; Baiduspider/2.0; +http://', 1518301453, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('8efc05da3ddb1078ee9156ea30f2c5bd', '107.77.64.54', 'Mozilla/5.0 (iPhone; CPU iPhone OS 11_2_5 like Mac', 1518306507, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('0820d0a14089b7a4dd79fd3fb987b6c7', '107.77.64.54', 'Mozilla/5.0 (iPhone; CPU iPhone OS 11_2_5 like Mac', 1518306515, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('c350a5a89ea90aae50075c11d8f93856', '107.77.68.82', 'Mozilla/5.0 (iPhone; CPU iPhone OS 11_2_5 like Mac', 1518306523, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('68bfc2e34eeda4057aa1f259b095ab98', '107.77.68.82', 'Mozilla/5.0 (iPhone; CPU iPhone OS 11_2_5 like Mac', 1518306528, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('b015a1d691bfb7bac3ac1f258de3c7f3', '107.77.64.54', 'Mozilla/5.0 (iPhone; CPU iPhone OS 11_2_5 like Mac', 1518306532, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('1dcc7e3d81f3775844dc6a29758d42d2', '107.77.64.54', 'Mozilla/5.0 (iPhone; CPU iPhone OS 11_2_5 like Mac', 1518306572, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('13e8558973997b1b7514b6b94ebb5e63', '107.77.64.54', 'Mozilla/5.0 (iPhone; CPU iPhone OS 11_2_5 like Mac', 1518306604, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('3df980291c37301f428dab8cba7db658', '107.77.68.82', 'Mozilla/5.0 (iPhone; CPU iPhone OS 11_2_5 like Mac', 1518306611, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('d5e92659e036230dbcabbd2d6c91fc2f', '107.77.64.54', 'Mozilla/5.0 (iPhone; CPU iPhone OS 11_2_5 like Mac', 1518306617, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('27e511c62d3160a5ba43c39a11256cf1', '107.77.64.54', 'Mozilla/5.0 (iPhone; CPU iPhone OS 11_2_5 like Mac', 1518306621, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('a49cb84d4f0d9ea2b8b352dcb71b33d8', '107.77.64.54', 'Mozilla/5.0 (iPhone; CPU iPhone OS 11_2_5 like Mac', 1518306625, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('dbfb12debfbda36064ec21cf347f2717', '107.77.64.54', 'Mozilla/5.0 (iPhone; CPU iPhone OS 11_2_5 like Mac', 1518306633, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('a53620d7aff23897fa527ad0b3166eb8', '74.115.214.132', 'Mozilla/5.0 (compatible; Uptimebot/1.0; +http://ww', 1518310112, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('f206219d950a671e2ef6884dbcfac5da', '74.115.214.149', 'Mozilla/5.0 (compatible; Uptimebot/1.0; +http://ww', 1518310112, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('2f67ddac1d341f54556f7b9ec4fdb3e0', '216.244.66.199', 'Mozilla/5.0 (compatible; DotBot/1.1; http://www.op', 1518319514, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('f6fddbd5737e608f4234c6953b8f5716', '54.36.149.14', 'Mozilla/5.0 (compatible; AhrefsBot/5.2; +http://ah', 1518328466, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('c0497a9cd81b90474558336384ca36ca', '216.244.66.199', 'Mozilla/5.0 (compatible; DotBot/1.1; http://www.op', 1518337566, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('601318901a7b91f609c4843e27903b39', '5.188.211.13', 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;', 1518338886, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('d76b80cb27ca637a87092abd3ca87c21', '5.188.211.13', 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;', 1518338886, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('953e99bcde1cdad52940e019ae9b0203', '5.188.211.13', 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;', 1518338889, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('49def2e80c99c2b6beeaf809a1b23e1b', '5.188.211.13', 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;', 1518338890, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('6412c49d864ea1554b4fe06d248616b3', '5.188.211.13', 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;', 1518338892, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('c3121d33276644e1714b0498d25aa4ae', '5.188.211.13', 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;', 1518338893, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('48793de60eafe3a0f372dd5db14487bc', '5.188.211.13', 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;', 1518338893, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('6507eb91360a2166892919dce77d3209', '5.188.211.13', 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;', 1518338894, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('3c3592eed987c755d23352da4a227898', '180.76.15.17', 'Mozilla/5.0 (compatible; Baiduspider/2.0; +http://', 1518343577, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('65fc73e9e7da73eb9fc6065ac7f78c27', '207.46.13.98', 'Mozilla/5.0 (compatible; bingbot/2.0; +http://www.', 1518345584, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('4d4bc80b8bc6b78b2c92917ae601e502', '13.56.229.65', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) Ap', 1518349173, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('e14a05f18f20fd76e8440a4f335179f0', '188.27.11.241', 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/53', 1518350045, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('126db90cd6e5c59b483e460f2eb974e3', '66.249.65.138', 'Mozilla/5.0 (compatible; Googlebot/2.1; +http://ww', 1518356920, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('053c2946644f094dca7efc08ea9ce09f', '207.46.13.101', 'Mozilla/5.0 (compatible; bingbot/2.0; +http://www.', 1518359477, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('d594377963dd10cb8473be0701c6a2ee', '207.46.13.99', 'Mozilla/5.0 (compatible; bingbot/2.0; +http://www.', 1518359612, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('7695fcf90d4391a46b9977fd5e17dfb3', '207.46.13.98', 'Mozilla/5.0 (compatible; bingbot/2.0; +http://www.', 1518359734, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('317b931130d001ffad5dc5c88e304030', '207.46.13.101', 'Mozilla/5.0 (compatible; bingbot/2.0; +http://www.', 1518359818, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('be5c5b3ba67bf0dfeabb496078d24783', '207.46.13.101', 'Mozilla/5.0 (compatible; bingbot/2.0; +http://www.', 1518359829, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('5608c633118ebda1928d1ebdbd04b838', '187.254.158.27', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:58.0)', 1518360184, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('fe1c5585c41100d8dc9f803d999f6da7', '187.254.158.27', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:58.0)', 1518360184, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('ec738802d846c12002e281cec1d7a8dd', '187.254.154.35', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:58.0)', 1518360238, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('4d2f00cb91bcb03580eab1fd3534ed5a', '187.254.154.35', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:58.0)', 1518360238, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('3478b91545e8a6d39c7e57b1ee5edfc4', '187.254.154.35', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:58.0)', 1518360249, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('327638c4b4c693e1f498528574a4a5f3', '187.254.147.106', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:58.0)', 1518360263, 'a:3:{s:9:\"user_data\";s:0:\"\";s:8:\"username\";s:6:\"robert\";s:12:\"is_logged_in\";b:1;}');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('3114cc0ac511dd572f91862e5676eb49', '187.254.147.106', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:58.0)', 1518360263, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('f26ac234c77799bfedbc21b42471fb7b', '187.254.147.106', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:58.0)', 1518360264, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('69f0a8882e79e4679e30ec3470e2a2dc', '187.254.147.106', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:58.0)', 1518360273, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('7acfa9d37c90ff2623aaf4908b92c533', '187.254.154.35', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:58.0)', 1518360308, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('250b59f68cc69400ef139510ab6b189b', '187.254.154.35', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:58.0)', 1518360320, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('afceb58a8770eced6d93cdc4829b63bb', '157.55.39.41', 'Mozilla/5.0 (compatible; bingbot/2.0; +http://www.', 1518360574, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('61e1d4a312761a46bee72c375292913b', '67.217.35.167', 'Mozilla/5.0 (Unknown; Linux x86_64) AppleWebKit/53', 1518361575, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('da3550edac8e6660a7321e7e2385c95f', '187.254.148.197', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:58.0)', 1518361757, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('3ba0712f063d48d3e0a7264478bda2ea', '187.254.148.197', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:58.0)', 1518361761, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('85377e09904a19114e3db85561cc688a', '187.254.148.197', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:58.0)', 1518362656, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('c76cafb6268a5e11b390203b5c05b527', '187.254.148.197', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:58.0)', 1518362662, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('700d85af5fdcc6e342a991b5e027ec12', '187.254.148.197', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:58.0)', 1518362917, '');
INSERT INTO ci_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('9b2641bdc3ece90c1447c7853102aab6', '187.254.148.197', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:58.0)', 1518362922, '');


#
# TABLE STRUCTURE FOR: image
#

DROP TABLE IF EXISTS image;

CREATE TABLE `image` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `item` int(11) NOT NULL DEFAULT '0',
  `name` varchar(25) NOT NULL DEFAULT '0',
  `width` int(11) NOT NULL DEFAULT '0',
  `height` int(11) NOT NULL DEFAULT '0',
  `next_image` int(11) NOT NULL DEFAULT '0',
  `prev_image` int(11) NOT NULL DEFAULT '0',
  `sort_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=325 DEFAULT CHARSET=latin1;

INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (1, 1, '182', 300, 225, 2, 0, 1);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (2, 1, '183', 300, 225, 0, 1, 2);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (3, 2, '177', 300, 225, 6, 4, 2);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (4, 2, '178', 300, 225, 3, 0, 1);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (5, 2, '179', 300, 225, 0, 7, 5);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (6, 2, '180', 300, 225, 7, 3, 3);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (7, 2, '181', 300, 225, 5, 6, 4);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (8, 3, '174', 300, 225, 0, 9, 3);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (9, 3, '176', 300, 225, 8, 10, 2);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (10, 3, '175', 300, 225, 9, 0, 1);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (11, 14, '173', 300, 400, 13, 50, 21);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (12, 5, '172', 300, 400, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (13, 14, '171', 300, 400, 0, 11, 22);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (14, 7, '170', 300, 225, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (15, 8, '166', 300, 225, 16, 0, 1);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (16, 8, '167', 300, 225, 17, 15, 2);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (17, 8, '168', 300, 400, 18, 16, 3);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (18, 8, '169', 300, 211, 0, 17, 4);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (19, 9, '165', 300, 225, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (20, 10, '162', 300, 400, 21, 0, 1);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (21, 10, '163', 300, 640, 22, 20, 2);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (22, 10, '164', 300, 400, 0, 21, 3);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (23, 11, '157', 300, 233, 24, 0, 1);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (24, 11, '158', 300, 301, 25, 23, 2);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (25, 11, '159', 300, 225, 26, 24, 3);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (26, 11, '160', 300, 221, 27, 25, 4);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (27, 11, '161', 300, 225, 0, 26, 5);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (28, 12, '155', 300, 400, 0, 29, 2);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (29, 12, '156', 300, 225, 28, 0, 1);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (30, 13, '153', 300, 400, 0, 0, 1);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (31, 150, '154', 300, 225, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (32, 14, '134', 300, 469, 34, 33, 2);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (33, 14, '135', 300, 400, 32, 0, 1);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (34, 14, '136', 300, 400, 35, 32, 4);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (35, 14, '137', 300, 225, 36, 34, 5);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (36, 14, '138', 300, 225, 37, 35, 6);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (37, 14, '139', 300, 400, 38, 36, 7);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (38, 14, '140', 300, 400, 39, 37, 8);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (39, 14, '141', 300, 225, 40, 38, 9);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (40, 14, '142', 300, 225, 41, 39, 10);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (41, 14, '143', 300, 225, 42, 40, 11);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (42, 14, '144', 300, 225, 43, 41, 12);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (43, 14, '145', 300, 225, 44, 42, 13);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (44, 14, '146', 300, 400, 45, 43, 14);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (45, 14, '147', 300, 225, 46, 44, 15);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (46, 14, '148', 300, 400, 47, 45, 16);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (47, 14, '149', 300, 225, 48, 46, 17);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (48, 14, '150', 300, 400, 49, 47, 18);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (49, 14, '151', 300, 400, 50, 48, 19);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (50, 14, '152', 300, 400, 11, 49, 20);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (51, 15, '131', 300, 225, 52, 0, 1);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (52, 15, '132', 300, 225, 53, 51, 2);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (53, 15, '133', 300, 225, 0, 52, 3);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (55, 16, '130', 500, 400, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (56, 17, '121', 300, 225, 57, 0, 1);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (57, 17, '122', 300, 225, 58, 56, 2);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (58, 17, '123', 300, 225, 59, 57, 3);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (59, 17, '124', 300, 400, 60, 58, 4);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (60, 17, '125', 300, 400, 61, 59, 5);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (61, 17, '126', 300, 225, 62, 60, 6);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (62, 17, '127', 300, 225, 63, 61, 7);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (63, 17, '128', 300, 400, 0, 62, 8);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (64, 18, '119', 300, 491, 65, 0, 1);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (65, 18, '120', 300, 225, 0, 64, 2);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (66, 19, '118', 300, 225, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (67, 20, '117', 300, 191, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (68, 21, '116', 300, 225, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (69, 22, '112', 300, 344, 70, 0, 1);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (70, 22, '113', 300, 507, 71, 69, 2);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (71, 22, '114', 300, 400, 0, 70, 3);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (72, 23, '98', 300, 225, 73, 0, 1);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (73, 23, '97', 300, 400, 74, 72, 2);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (74, 23, '94', 300, 420, 75, 73, 3);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (75, 23, '95', 300, 400, 76, 74, 4);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (76, 23, '96', 300, 400, 0, 75, 5);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (78, 25, '92', 300, 225, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (79, 26, '91', 300, 225, 80, 0, 1);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (80, 26, '90', 300, 225, 81, 79, 2);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (81, 26, '89', 300, 225, 0, 80, 3);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (82, 27, '86', 300, 225, 83, 0, 1);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (83, 27, '87', 300, 225, 84, 82, 2);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (84, 27, '88', 300, 225, 0, 83, 3);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (85, 28, '83', 300, 225, 86, 0, 1);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (86, 28, '84', 300, 225, 87, 85, 2);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (87, 28, '85', 300, 225, 0, 86, 3);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (88, 29, '77', 300, 225, 0, 89, 6);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (89, 29, '78', 300, 225, 88, 90, 5);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (90, 29, '79', 300, 225, 89, 91, 4);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (91, 29, '80', 300, 225, 90, 92, 3);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (92, 29, '81', 300, 225, 91, 93, 2);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (93, 29, '82', 300, 225, 92, 0, 1);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (94, 30, '73', 300, 225, 95, 0, 1);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (95, 30, '74', 300, 225, 0, 94, 2);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (96, 31, '76', 300, 225, 0, 100, 10);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (97, 31, '70', 300, 225, 98, 0, 2);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (98, 31, '71', 300, 225, 99, 97, 3);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (99, 31, '72', 300, 225, 100, 98, 4);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (100, 31, '75', 300, 400, 96, 99, 5);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (101, 32, '67', 300, 156, 102, 0, 1);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (102, 32, '68', 300, 94, 103, 101, 2);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (103, 32, '69', 300, 161, 0, 102, 3);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (104, 33, '66', 300, 400, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (105, 34, '65', 300, 106, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (106, 35, '64', 300, 225, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (107, 36, '63', 300, 225, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (108, 37, '61', 300, 225, 109, 0, 1);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (109, 37, '62', 300, 225, 0, 108, 2);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (110, 38, '60', 300, 225, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (111, 39, '59', 300, 400, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (112, 40, '58', 300, 225, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (113, 41, '53', 300, 400, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (114, 42, '54', 300, 225, 0, 115, 4);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (115, 42, '55', 300, 225, 114, 116, 3);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (116, 42, '56', 300, 225, 115, 117, 2);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (117, 42, '57', 300, 225, 116, 0, 1);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (118, 43, '46', 300, 225, 119, 0, 1);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (119, 43, '47', 300, 225, 0, 118, 2);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (120, 44, '50', 300, 225, 121, 0, 1);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (121, 44, '48', 300, 225, 122, 120, 2);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (122, 44, '49', 300, 225, 123, 121, 3);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (123, 44, '51', 300, 225, 124, 122, 4);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (124, 44, '52', 300, 225, 0, 123, 5);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (126, 46, '44', 300, 225, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (127, 47, '43', 300, 225, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (128, 48, '42', 300, 213, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (129, 49, '41', 300, 233, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (130, 50, '39', 300, 218, 131, 0, 1);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (131, 50, '40', 300, 225, 0, 130, 2);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (132, 51, '37', 300, 225, 133, 0, 1);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (133, 51, '38', 300, 225, 0, 132, 2);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (134, 52, '35', 300, 225, 135, 0, 1);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (135, 52, '36', 300, 225, 0, 134, 2);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (136, 53, '31', 300, 400, 137, 0, 1);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (137, 53, '32', 300, 400, 138, 136, 2);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (138, 53, '33', 300, 225, 139, 137, 3);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (139, 53, '34', 300, 225, 0, 138, 4);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (140, 54, '30', 328, 225, 141, 0, 1);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (141, 54, '29', 328, 440, 0, 140, 2);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (142, 55, '28', 304, 442, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (143, 56, '26', 300, 225, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (144, 57, '27', 265, 400, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (145, 58, '25', 300, 193, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (146, 59, '01', 200, 350, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (147, 60, '107', 300, 426, 148, 0, 1);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (148, 60, '99', 300, 316, 149, 147, 2);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (149, 60, '100', 300, 396, 150, 148, 3);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (150, 60, '101', 300, 389, 151, 149, 4);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (151, 60, '104', 300, 514, 152, 150, 5);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (152, 60, '102', 300, 449, 153, 151, 6);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (153, 60, '105', 300, 225, 154, 152, 7);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (154, 60, '106', 300, 486, 155, 153, 8);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (155, 60, '103', 300, 400, 156, 154, 9);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (156, 60, '108', 300, 400, 157, 155, 10);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (157, 60, '109', 300, 400, 158, 156, 11);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (158, 60, '110', 300, 400, 159, 157, 12);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (159, 60, '111', 300, 400, 160, 158, 13);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (160, 60, '115', 300, 400, 0, 159, 14);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (161, 61, '24', 300, 206, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (162, 62, '23', 300, 233, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (163, 63, '22', 248, 375, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (164, 64, '21', 250, 375, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (166, 66, '19', 300, 175, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (167, 67, '18', 300, 183, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (168, 68, '17', 300, 455, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (169, 69, '16', 300, 239, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (171, 71, '14', 300, 197, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (172, 72, '13', 300, 170, 258, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (173, 73, '12', 300, 432, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (174, 74, '11', 300, 392, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (175, 75, '10', 288, 380, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (176, 76, '09', 300, 206, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (177, 77, '08', 300, 268, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (178, 78, '07', 300, 198, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (179, 79, '06', 300, 150, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (180, 80, '05', 300, 201, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (181, 81, '04', 300, 189, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (182, 82, '03', 300, 187, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (183, 83, '02', 300, 442, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (184, 84, '13', 212, 311, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (185, 85, '14', 300, 345, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (186, 86, '15', 300, 389, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (187, 87, '16', 213, 311, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (188, 88, '17', 210, 314, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (189, 89, '12', 300, 400, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (190, 90, '04', 300, 335, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (191, 91, '05', 260, 350, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (192, 92, '06', 300, 408, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (193, 93, '07', 300, 241, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (194, 94, '08', 300, 233, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (195, 95, '09', 300, 235, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (196, 96, '10', 300, 252, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (197, 97, '26', 300, 237, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (198, 98, '18', 300, 400, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (199, 99, '19', 300, 400, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (200, 100, '20', 300, 302, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (201, 101, '21', 300, 398, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (202, 102, '22', 300, 288, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (203, 103, '23', 300, 384, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (204, 104, '24', 300, 400, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (205, 105, '25', 300, 304, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (206, 106, '27', 300, 304, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (207, 107, '28', 300, 251, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (208, 108, '01', 300, 199, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (209, 109, '02', 300, 199, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (210, 110, '03', 300, 385, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (211, 111, '04', 242, 354, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (212, 112, '05', 300, 194, 262, 0, 1);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (213, 113, '06', 300, 237, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (214, 114, '07', 300, 278, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (215, 115, '08', 300, 307, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (216, 116, '09', 300, 307, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (217, 117, '01', 300, 225, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (218, 118, '02', 300, 216, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (219, 119, '03', 300, 130, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (220, 120, '04', 300, 182, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (221, 121, '05', 300, 387, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (222, 122, '06', 300, 383, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (223, 123, '07', 300, 311, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (224, 124, '08', 300, 211, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (225, 125, '09', 300, 355, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (226, 126, '10', 300, 288, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (227, 127, '12', 300, 225, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (228, 128, '13', 300, 225, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (229, 129, '14', 300, 225, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (230, 130, '15', 300, 225, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (231, 131, '16', 300, 225, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (232, 132, '17', 600, 400, 234, 0, 1);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (233, 132, '18', 600, 343, 235, 234, 3);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (234, 132, '19', 300, 400, 233, 232, 2);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (235, 132, '20', 300, 400, 0, 233, 4);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (236, 133, '21', 600, 450, 237, 0, 1);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (237, 133, '22', 338, 450, 238, 236, 2);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (238, 133, '23', 600, 450, 239, 237, 3);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (239, 133, '24', 600, 450, 240, 238, 4);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (240, 133, '25', 600, 450, 241, 239, 5);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (241, 133, '26', 338, 450, 242, 240, 6);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (242, 133, '27', 338, 450, 0, 241, 7);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (243, 134, '28', 600, 450, 244, 0, 1);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (244, 134, '29', 600, 450, 245, 243, 2);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (245, 134, '30', 600, 450, 0, 244, 3);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (246, 135, '01', 300, 201, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (247, 136, '02', 300, 423, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (248, 137, '03', 300, 167, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (249, 138, '04', 300, 191, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (250, 139, '05', 300, 195, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (251, 140, '06', 300, 203, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (252, 141, '07', 300, 457, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (253, 142, '08', 300, 180, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (254, 143, '09', 300, 225, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (255, 144, '10', 300, 225, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (256, 145, '11', 300, 225, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (257, 146, '12', 300, 250, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (258, 72, '13a', 300, 196, 0, 172, 2);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (259, 147, '15', 300, 195, 0, 0, 1);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (260, 148, '20', 285, 199, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (261, 149, '93', 300, 225, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (262, 112, '05a', 300, 228, 0, 212, 2);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (263, 151, '184', 383, 400, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (264, 152, '185', 400, 360, 0, 0, 0);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (265, 153, '186', 533, 400, 266, 0, 1);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (266, 153, '187', 300, 400, 0, 265, 2);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (267, 154, '188', 533, 400, 268, 0, 1);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (268, 154, '189', 300, 400, 269, 267, 2);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (269, 154, '190', 533, 400, 270, 268, 3);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (270, 154, '191', 533, 400, 0, 269, 4);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (271, 155, '194', 467, 350, 272, 274, 3);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (272, 155, '195', 467, 350, 273, 271, 4);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (273, 155, '196', 467, 350, 0, 272, 5);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (274, 155, '193', 467, 350, 271, 275, 2);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (275, 155, '192', 467, 350, 274, 0, 1);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (276, 156, '197', 480, 360, 277, 0, 1);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (277, 156, '198', 480, 360, 278, 276, 2);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (278, 156, '199', 480, 360, 0, 277, 3);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (279, 157, '200', 480, 360, 280, 0, 1);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (280, 157, '201', 480, 360, 281, 279, 2);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (281, 157, '202', 480, 360, 0, 280, 3);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (282, 158, '203', 270, 360, 283, 0, 1);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (283, 158, '204', 480, 360, 284, 282, 2);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (284, 158, '205', 480, 360, 285, 283, 3);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (285, 158, '206', 480, 360, 0, 284, 4);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (288, 161, '208', 360, 480, 0, 0, 1);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (287, 160, '207', 480, 155, 0, 0, 1);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (289, 162, '31', 480, 360, 290, 0, 1);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (290, 162, '32', 480, 360, 291, 289, 2);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (291, 162, '33', 480, 360, 292, 290, 3);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (292, 162, '34', 480, 360, 293, 291, 4);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (293, 162, '35', 480, 360, 294, 292, 5);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (294, 162, '36', 480, 360, 0, 293, 6);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (297, 163, '211', 359, 480, 298, 296, 3);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (296, 163, '210', 480, 359, 297, 295, 2);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (295, 163, '209', 480, 359, 296, 0, 1);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (298, 163, '212', 480, 359, 299, 297, 4);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (299, 163, '213', 480, 359, 0, 298, 5);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (300, 164, '214', 480, 359, 301, 0, 1);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (301, 164, '215', 480, 359, 302, 300, 2);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (302, 164, '216', 480, 359, 0, 301, 3);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (303, 165, '13', 480, 359, 304, 0, 1);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (304, 165, '14', 480, 359, 305, 303, 2);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (305, 165, '15', 359, 480, 306, 304, 3);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (306, 165, '16', 480, 359, 307, 305, 4);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (307, 165, '17', 480, 359, 0, 306, 5);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (308, 166, '18', 480, 359, 0, 0, 1);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (309, 167, '214', 297, 480, 0, 0, 1);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (310, 168, '217', 358, 480, 0, 0, 1);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (311, 169, '215', 480, 480, 0, 0, 1);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (312, 170, '29', 480, 320, 0, 0, 1);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (313, 171, '30', 480, 480, 0, 0, 1);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (314, 172, '31', 480, 308, 0, 0, 1);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (315, 173, '32', 480, 247, 0, 0, 1);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (316, 174, '33', 480, 321, 0, 0, 1);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (317, 175, '34', 480, 365, 0, 0, 1);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (318, 176, '35', 480, 397, 0, 0, 1);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (319, 177, '36', 480, 311, 0, 0, 1);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (320, 178, '37', 480, 390, 0, 0, 1);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (322, 180, '38', 480, 319, 0, 0, 1);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (323, 181, '39', 480, 317, 0, 0, 1);
INSERT INTO image (`id`, `item`, `name`, `width`, `height`, `next_image`, `prev_image`, `sort_order`) VALUES (324, 182, 'Peaceful Walk', 377, 480, 0, 0, 1);


#
# TABLE STRUCTURE FOR: item
#

DROP TABLE IF EXISTS item;

CREATE TABLE `item` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '0',
  `page` int(11) NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=183 DEFAULT CHARSET=latin1;

INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (1, '182', 1, 'Who Let The Dogs Out', '<p> Home is where the heart is, and my clients heart is in Laguna Beach, He just happens to live in Arizona. His wife was the Sun Goddess while he went body surfing.  Gracie, the Golden Retriever was then added to their blissful life and about two years ago, their son got Winston the Border Collie. After going to an art show at Tempe Town Lake, they fell in love with this wood carved car.  Combining all the elements, we all put our heads together and created </p>', 182);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (2, '181', 1, '', '<p></p>', 181);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (3, '174', 1, '', '<p></p>', 174);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (5, '172', 1, '', '<p>&nbsp;</p>', 172);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (7, '170', 1, '', '<p>The oldest child wanted &ldquo;rainbow zebra&rdquo; on her walls.  Luckily Mom found sheets and I made the wall design.  This was for her 8th birthday.</p>', 170);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (8, '166', 1, '', '<p>The middle child wanted flowers and butterflies in her room.  This is special since she wanted her own room and not share it with her younger sister.</p>', 166);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (9, '165', 1, '', '<p>The youngest boy wants to be a Fireman when he grows up, so we added a Fire Truck coming down from the hills and a fire pit for the fire fighters to sit around.</p>', 165);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (10, '162', 1, '', '<p>All the trees are the shapes of the kids in the house.  Each got to pose and make their own \"special tree.\"  I actually outlined their bodies and made them trees.</p><p>The theme was a garden with mountains and waterfalls.  Bringing the children and family together.</p>', 162);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (11, '157', 1, '', '<p>Sometimes peace and tranquility can be found in the most unsuspecting places, even a bathroom.</p>', 157);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (12, '156', 1, '', '<p>As per usual, I try to put a little something personal in my murals.  So, the two people walking the trail are the children of my clients.  And I painted four quail to represent their family.  They loved it.</p>', 156);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (13, '153', 1, '', '<p>The picture of the cat\'s is in their guest bathroom and  the only real shelf is the one with the towels on it.  \"Lee Marvin\" is the cat on the painted shelf and \"Diamond\" is reaching up to him.</p>', 153);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (14, '141', 1, '', '<p>This client wanted to have a mission feeling in her home.  She had been out of town for two months and I had to do this without her or her husband there.  She definitely got a WOW when she came home.  We had agreed on images before she left, but, this was all a total awe-inspiring feeling when she and her husband returned.</p><p>Befores and Afters</p>', 141);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (15, '132', 1, '', '<p>These are the for same client as the chef.  She had this wall in the backyard that was just an eye sore.  Now it is a desert tranquility.</p>', 132);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (16, '130', 1, '', '<p>This is the before and after of a client who needed a special chef to make her smile.  On his apron is the name Lorenzo for her son.  On the tray is a great bottle of Pino Grigio that bares her last name.  A great loaf of bread and some cheese and grapes brings a great smile to her face everyday.</p>', 130);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (17, '121', 1, '', '', 121);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (18, '119', 1, '', '', 119);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (19, '118', 1, '', '<p>The idea here was to keep the colors in her bathroom plus have a shelf for her favorite shells and stones she collects from all her travels.  Because it was a small area, I thought a &ldquo;breeze coming through a window&rdquo; would add the mood to this room.  It did and she loves to show it off with her stones.  She just came back from Isreal and she has stones from &ldquo;the Wailing Wall&rdquo; and the Gaza Strip area.I love to bring that personal touch to everyone\'s mural.</p>', 118);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (20, '117', 1, '', '<p>&nbsp;</p>', 117);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (21, '116', 1, '', '<p>&nbsp;</p>', 116);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (22, '112', 1, '', '<p>Kansas may be home to my client and Dorothy and her friends help, but,  in reality, the colors of the rainforest with their flowers ,greenery  and exotic birds bring life to an already hectic lifestyle. We can  almost hear the noises of the birds and the rustling of leaves.</p>', 102);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (23, '94', 1, '', '<p>My client originally wanted three arched windows with a Tuscan scene.  Her husband wanted to leave the wall blank.  We needed to put something there, keep the elegance and the Tuscan feel while pleasing everyone.  We came up with the columns and then the urns.  Now everyone loves it.  In fact, we will be adding columns around the statue with a faux finish on the wall behind it.  Guests all have the same comment, \"Wow!\".</p>', 94);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (25, '92', 1, '', '<p>The window mural is the spa owners favorite place. Laguna Beach. The family go there often. This is her favorite deck looking out a the beach.</p>', 92);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (26, '91', 1, '', '<p>Well, if you have to do laundry, you might as well do it outside - even when you can\'t go outside. Here my client wanted that special touch. So whether the door is open or shut, she has a great looking laundry area.</p>', 91);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (27, '86', 1, '', '<p>This client wanted to have a continuation of her mountains and desert surroundings on her wall.These are the beginning middle and end of her wall. Then to really add punch, I hid the names of all her grandchildren in the mural. They then play \"I Spy\" and they have to find there names. Too cute. </p>', 86);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (28, '83', 1, '', '<p>These pix are of Pam\'s wall I did a year ago.</p>', 83);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (29, '77', 1, '', '<p>To continue the look in Pam\'s yard, we added \"the city lights\" scene on her north eastern wall.  However, her husband wanted to see the Canyon Lake.  So that was added at the end of the wall.To add punch, I put on a glitter paint that adds sparkle at night.   Now, the city lights glow behind the buildings and the lights in the buildings.  A real show stopper for her parties.</p>', 77);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (30, '73', 1, '', '<p>Outside</p>', 73);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (31, '70', 1, '', 'The murals you look at through the curtained window is of the bench with a window and curtain blowing in the bridge. ', 70);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (32, '67', 1, '', 'When this project started, my client already had several chef-themed items (eg: placemats, towels, dishes). At first, I explored additional chef images but then, creativity struck and I started adding tables, vegetables, fruit and other related items. The additional items enabled me to create a 3-dimensional illusion. To finish the set, I added butlers to the cabinet sides as well as a few simple table settings. When completed, it added great dimension to the room and my clients now love their kitchen. ', 67);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (33, '66', 1, '', 'Having just completed a mural on my clients exterior wall and a â€œfauxâ€ finish on the interior wall, I felt that the adjacent window now looked inappropriately bare. Again, creativity struck and I thought that the illusion of curtains framing the window would enrich the window while enhancing the view of the interior and exterior walls. I researched curtain options and found a beaded style that worked perfectly. My client agreed and I decided to paint the curtains and then add actual beading to give a third dimension. The completed set of the walls and the window is now quite a conversation piece.', 66);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (34, '65', 1, '', 'This mountain scene is actually seen from my clients backyard. This is on soffit area over their sliding doors.', 65);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (35, '64', 1, '', 'And you thought the space under your kitchen counter was safe. Here is an idea to hide toe smudges.', 64);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (36, '63', 1, '', 'And more over the counter designs.', 63);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (37, '61', 1, '', 'More ideas for over the cabinets.', 61);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (38, '60', 1, '', 'Here\'s an idea for over the stove in the kitchen. ', 60);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (39, '59', 1, '', 'How about hiring your own personal chef. And, you can change the menu any day of the week. ', 59);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (40, '58', 1, '', '<p>What about a nice soft misty effect over a sofa?  This could be blended into the wall.</p>', 58);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (41, '53', 1, '', 'Here\'s an idea for that flat wall at the end of a hall. Yep, that is a flat wall, but the illusion is much deeper.', 53);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (42, '57', 1, '', 'Before and afters of a dining room wall. Give me the country life!', 57);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (43, '46', 1, '', 'Here is a great idea. Do you love a picture and wish there were more? Well, let\'s expand the scene. With or without the picture its a great idea for a mural.', 46);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (44, '48', 1, '', 'A boy who loves to see all the mountains surrounding the home he lives in. This is his place to dream.', 48);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (46, '44', 1, '', 'Arizona has such unique and beautiful scenery . Even in a carport of a trailer home, you can capture these views. It\'s the end of the trail for this RV\'er.', 44);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (47, '43', 1, '', 'Many new homes today, have high ceilings and they are in a quandry as to what and how to decorate over the cabinets. This client lives in Cave Creek/Scottsdale area. Keeping the mood of Arizona and his views all around, you can see how adding a mural can creatively take up -  negative areas.', 43);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (48, '42', 1, 'Ya\' hoo', '<p>Isn\'t this a great whimsical, fun mural.&nbsp; My client really had fun getting me to do this.&nbsp; How perfect for her living room.&nbsp; Light, airy and just neat to look at.&nbsp; Ya\'hoo, round \'em boys and let\'s ride! </p>', 42);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (49, '41', 1, '', '<p>This mural is in a mobile home park.  Instead of looking at a blank wall, they now have a great view of the Superstition Mountains. My clients do a lot of hiking in the Superstition and this brings them wonderful memories everyday.</p>', 41);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (50, '39', 1, '', 'My client built a fireplace and wanted to keep that same look over it.  Also, to keep the continuity flowing, I painted the back of their cabinets to blend with the room.  It\'s a wonderful old world feeling.', 39);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (51, '37', 1, '', '<p> These are on a wall under their staircase.  They just bought the bronze statue of the little children on a park bench.  Wasn\'t that a wonderful idea to add the park behind them?</p>', 37);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (52, '35', 1, ' Painting on Tiles', '<p> As you can see, I can also paint on tile.  This family actually had me in mind when they started to re-decorate their home.</p>', 35);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (53, '31', 1, 'New Orleans', '<p> This is one room of my clients home that she wanted painted as Bourbon Street in New Orleans.  She is a music teacher and her daughter plays the Harp and a friend plays the sax.  As you can see I put her friends in the picture.  This home is just a wonderful place to gather and listen to great music and laughter.  I really enjoyed doing this.  Her daughter would practice playing the harp while I worked.</p>', 31);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (54, '29', 1, ' Marshalls Mural and Kristin\'s Mural', '<p>Both of these murals are in a clients home that has a built in wine cellar.  Marshall\'s mural has a window that was painted to \"look into\" the wine cellar from the bar.  Krisitin\'s mural is just to the right of the cellar and gives that feeling of walking out onto a patio and seeing the vineyard.</p>', 29);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (55, '28', 1, 'The Casita', '<p> This is a bare wall that is part of a room off the entrance of my client\'s home.  They wanted that open feeling.  Since my client built their home, I incorporated the same wood he put throughout his home.  The window\'s are the same as his casita outside.  The flagstone is the same as what they have in their home and outside.  Can you see their cats? </p>', 28);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (56, '26', 1, 'A Scene from Africa', '<p>This is a dining room that was very plain and needed some color and personality.&nbsp; My clients home is done in the African motif and we brought that theme into this room.&nbsp; The colors are coordinated with the rest of the house.&nbsp; She has spears and masks to put on the outside of the walls.&nbsp; Now you get a feeling of being in the jungles of Africa, but with a warm serene, comfortable atmosphere.&nbsp; Light some candles and you get a romantic atmosphere for dinner.&nbsp; Night or day you just love to be home. </p>', 26);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (57, '27', 1, 'The scene of the vineyard', '<p>This is a little cubby hole in a room off my clients living room and entryway.&nbsp; He uses the room for an office, however, he also has a Cockatoo and an African Grey.&nbsp; These birds get special treatment since I was commissioned to paint them a wine vineyard they would love to be in.&nbsp; The vines are painted on the wall so he can also have real vines attached and the birds can perch right on it.&nbsp; And you thought dogs get special treatment. </p>', 27);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (58, '25', 1, 'Anita\'s House', '<p>My client loves the Thomas Kincaid look.&nbsp; So we found a house and brought in the flowers and created an image that you can walk right into one of his pictures.&nbsp; Not really his, but, the feeling that you get from his pictures.&nbsp; I only wish I could grow a garden like I can paint them. </p>', 25);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (59, '01', 1, '', '<p>You are looking at a mural I did for a client\'s bathroom. We had a lot of fun doing this. It actually goes around the room on three walls. The fourth wall has her mirror over a double sink counter. When looking through the mirror you actually feel like you are in an aquarium. Her children just loved it.</p>', 1);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (60, '103', 1, '', '<p>This client has a huge heart for the kid in her as well as everyone she touches.  Her home is Kansas and she misses it.  She needed to feel her home roots although she is in Arizona.  There are times her life has \"tornado\" like events and that is the time she needs to feel her home roots again.</p> <p>With her friends Dorothy, The Tin Man, The Lion and Scarecrow, she can achieve anything.  Even the wicked witch of the west.  She is like Glinda the good witch who watches over all the \"munchkins\" in her home and gives her magic wand a twirl and everything is right again. She is a true believer in positive thinking, but just in case she has some \"flying monkeys\" to help chase away evil. This was alot of fun to paint and even more fun to add another wonderful person in my world. </p>', 103);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (61, '24', 1, 'Walk into my courtyard', '<p>This client knew exactly what they wanted. As you first enter the home you were faced with a blank wall. Now you are introduced to a courtyard. Really opens the place up.</p>', 24);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (62, '23', 1, 'Venice', '<p>This is done in a clients entryway. They spent there honeymoon there and loved this scene.</p>', 23);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (63, '22', 1, 'Rainforest', '<p>My client\'s home has the jungle effect. Her entryway was done in Zebra stripes and this is the master bathroom.</p>', 22);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (64, '21', 1, '', 'This and the previous are in the same home.  After I did the entrance in the Zebra stripes, I added accents in her kitchen and then she wanted to continue the theme in her master bathroom.  It\'s really a beautiful effect and her home is fun and exciting to be in. ', 21);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (66, '19', 1, '', '<p>I have wonderful people for clients and friends.  These people call themselves \"mushrooms\" (A bunch of funguy\'s)  They have this statue of a women sitting on the ledge over their fireplace.  It is a french women, so what better place to paint a french scene.  They really love it and it makes the statue come alive. </p>', 19);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (67, '18', 1, '', '<p>This scene is on a very long wall in my clients entryway.&nbsp; She had some pictures and I combined some ideas off some of her things in the room.&nbsp; However, she and I agreed on the patio effect. </p>', 18);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (68, '17', 1, '', '<p>This is an archway in a kitchen.&nbsp; She wanted something simple but elegant.&nbsp; Yum, Yum. </p>', 17);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (69, '16', 1, '', '<p>How would you like to be able to walk out onto your terrace and have the Grand Canyon for a view? That\'s what my client wanted and it only took me one and a half weeks to do what God took a lifetime to do. They are very pleased.</p>', 16);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (71, '14', 1, '', 'This is a bedroom ceiling and walls that I had to do for a bachelor.  He wanted that romantic feeling.  I then painted the next scene on his walls.  I wonder if he\'s still a bachelor now? ', 14);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (72, '13', 1, '', 'This was special.  Since it was for my very own granddaughter that was just born.  My daughter-in-law bought these towels with ducks on them and I had to do something for her.  Just tooo cute!! ', 13);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (73, '12', 1, '', 'My client has this wonderful cat that kept jumping up on the table and watching me paint.  I saw this empty space on the wall and talked it over with my client.  We both laughed about the idea and she just loved it.  The cat was confused. ', 12);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (74, '11', 1, '', '<p>My client had me do a southwest scene on her dining room wall and then wanted a design on her ceiling.  I went around her home and took patterns off of some rugs she had and I still had to paint around a huge chandelier.  This really brought a lot of pizazz to her room.</p>', 11);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (75, '10', 1, '', '<p>	This is my clients family.  They are all divers and they wanted to have a picture of all them together.  They got it and gave me a picture to use.  They were so excited, because, they were able to identify each member of the family from the mural.  What a great time they had.  How fun!!!! </p>', 10);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (76, '09', 1, '', '<p>This is the opposite wall of the prior scene. As you can see, with both these scenes, her room really opened up. From there, we had a great time decorating and shopping. Again, this wall is flat, including the pillar. </p>', 8);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (77, '08', 1, '', '<p>My client bought a new house which was very dark and cold. She needed to \"open\" the rooms up. Having a cathedral ceiling helped. Remember, this wall is really all flat. </p>', 9);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (78, '07', 1, '', '<p>These windows are Trompe l\'Oiel. After painting the windows, we decided to add the shutters. Which also meant we had to purchase real shutters for the real windows.</p>', 7);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (79, '06', 1, '', '<p>This client was into Feng Shui. I had to paint this mural using all the elements my client needed to create her Chi.</p>', 6);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (80, '05', 1, '', '<p>This is a dining room of a client who wanted curtains, but not the material kind.</p>', 5);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (81, '04', 1, '', 'Your daughter might want a garden for her bedroom. What an airy and good feeling this room has. ', 4);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (82, '03', 1, '', '<p>My client here lived in Africa most of her life. She is originally from Germany. Her home is very eclectic and there were challenges in decorating. Her chairs have an African design to it and I took the theme from them. This life size Giraffe fits perfectly on the side of her fireplace. And of course, we had to add the Acacia Tree.</p>\r\n\r\n<p>Unfortunately, you cannot see the wall to its left. I fauxed it to represent elephant skin. This brought the whole mood together.</p>', 3);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (83, '02', 1, '', 'This client needed to have this room done by Monday. She called me on Thursday night. She had an argument with another artist and fired her. We had to repaint the room and redo the walls and ceiling. I got the job done and she was delighted. ', 2);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (84, '13', 5, '&quot;Care Bears&quot;', '<p>Medium: Oil<br>Size: 24x30<br>Sold</p>', 13);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (85, '14', 5, '&quot;Cat&quot;', '<p>Sold<br>Medium: Scratchboard<br>Size:161/2x22<br>Price: $1250</p>', 14);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (86, '15', 5, '&quot;Lighthouse&quot;', '<p>Medium: Acrylic<br>Size: 18x24 unframed<br>Sold</p><p>Giclee available</p><p>Cards Available</p>', 15);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (87, '16', 5, 'Sailing ship', '<p>Sold<br>Medium: Acrylic<br> Size:24x18<br>Price: $375</p><p>Cards Available</p>', 16);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (88, '17', 5, 'Panda', '<p>Medium: Oil<br>Size: 24x30 - unframed<br>Sold</p>', 17);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (89, '12', 5, 'Sitting Ducks', '<p>Sold</p>\n<p>Cards Available</p>', 12);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (90, '04', 5, '&quot;Wise One&quot; - In Pencil', '<p>Medium: Giclee<br/>unframed<br/>Price: $150 </p><p>Cards Available</p>', 4);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (91, '05', 5, '&quot;Peace Pipe&quot; - In Pencil', '<p>Medium: Giclee<br/>unframed<br/>Price:  $150 </p><p>Cards Available</p>', 5);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (92, '06', 5, 'Stage Coach Driver', '<p>Medium: Acrylic<br>Size: 22 X 28 - unframed<br>Price: $500</p>', 6);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (93, '07', 5, 'Mexican Boy', '<p>Medium: Acrylic<br>Size: 16 X 20 - unframed<br>Price: $250</p><p>Cards Available</p>', 7);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (94, '08', 5, 'Joshua Tree National Forest', '<p>Sold</p>', 8);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (95, '09', 5, 'Sedona', '<p>Medium: Giclee<br>Size: 18 X 24<br>Price: $150</p><p>Cards Available</p>', 9);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (96, '10', 5, '&quot;My Hide Away&quot;', '<p>&nbsp;</p>', 10);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (97, '26', 5, '&quot;Nancy\'s Quiet Spot&quot;', '<p>Medium: Acrylic on Canvas.<br>Size: 23 X 18<br>Price: $450</p><p>Giclee available</p><p>Cards Available</p>', 26);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (98, '18', 5, '&quot;Innocence&quot;', '<p>Sold<br>Medium: Mixed media<br>Sold</p>', 18);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (99, '19', 5, '&quot;Proud Navajo&quot;', '<p>Medium: Charcoal<br>Price: $250</p>', 19);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (100, '20', 5, '&quot;Elephant Run&quot;', '<p>Sold<br>Size: 24 X 24 - Framed<br>Medium: Mixed Media on wood<br>Price: $650 - Framed</p>', 20);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (101, '21', 5, '&quot;Cowboy&quot;', '<p>Medium: colored pencil on wood<br>Size: 18 X 24 <br>Price: $500 - Unframed</p>', 21);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (102, '22', 5, '&quot;Ghost Dance&quot;', '<p>Sold<br>Medium: Mixed Media <br>Size: 24 X 24<br>Price: $500 - Unframed </p>', 22);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (103, '23', 5, '&quot;Girl and Her Doll&quot;', '<p>Sold<br>Medium: Charcoal <br>Size: 18 X 24<br>Price: $450 - Framed </p>', 23);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (104, '24', 5, '&quot;Mystique Fire&quot;', '<p>Medium: Giclee on Canvas<br>Size: 18 X 24<br>Price: $350 </p>', 24);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (105, '25', 5, '&quot;Wise One&quot;', '<p>Medium: Giclee<br>Size: 18 X 22 - Framed<br>Price: $250</p>', 25);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (106, '27', 5, '&quot;Peace Pipe&quot;', '<p>Framed</p>', 27);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (107, '28', 5, '&quot;The Three Tenors&quot;', '<p>&nbsp;</p>', 28);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (108, '01', 3, '', '<p>My client loved fish. So, what better way to get your kids to take a bath, than their very own fish tub. The kids love it and my client was thrilled with how whimsical it turned out.</p>', 1);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (109, '02', 3, '', '<p>My client loves to go to Garage Sales. Here, she found a very old beat up table. I stripped it, sanded it a did a faux stain to give it that rich look she needed. She then found a stone sink and had it inlaid for her bathroom.</p>', 2);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (110, '03', 3, '', '<p>Another client also loved to go to garage sales and found this chilidren\'s picnic table. Since I was painting in her home, she asked me to do this table for her.</p>', 3);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (111, '04', 3, '', '<p>I decorated my client\'s den as an old fashion movie theatre. Dark maroon walls, with that old theatre carpeting. Then I painted her door going into the laundry room as an old ticket booth. It really set the mood right.  </p>', 4);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (112, '05', 3, '', '<p>I took the floor that was just installed and continued it up the wall to open the room. My client was from Hawaii and wanted a volcano scene.</p>', 5);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (113, '06', 3, '', '<p>&nbsp;</p>', 6);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (114, '07', 3, '', '<p>&nbsp;</p>', 7);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (115, '08', 3, '', '<p>&nbsp;</p>', 8);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (116, '09', 3, '', '<p>&nbsp;</p>', 9);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (117, '01', 2, '', '<p>I was commissioned to paint a mural in the front lobby of the Auburn, CA jail. When I started to paint, the Captain asked if I wouldn\'t mind having some female inmates watch. I suggested that they can learn while watching. Before long, I was teaching the inmates to paint. My teaching progressed into a program for the female inmates. I taught them for 3 years until I moved out of the area. It was a very rewarding time for me. We were on T.V. and written up in the newspapers. The women were thrilled. </p>', 1);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (118, '02', 2, '', '<p>My client here is a dentist. When you sit in the exam chair, just overhead, he piped in the underwater sounds of the fish. The patients just loved this room.</p>', 2);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (119, '03', 2, '', '<p>This is a showroom for a client who sells ceiling fans. She wanted the room to look tropical. This is a plain flat wall. I fauxed the bottom part of the wall to match her counters. Then painted the windows. From there we got a little personal and added her cat and bird.</p>', 3);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (120, '04', 2, '', '<p>This is a mural inside an Exxon Mini-Mart. They have an Espresso Bar and wanted the European feeling. Everything on the wall is painted, bricks and all</p>', 4);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (121, '05', 2, '', '<p>We had a lot of fun on this job. It is actually a whole shopping center. This included a 50ft. driveway wall and several walls between each shop. This is one of the walls. When I arrived at work one day, the gardeners put 3 dirt balls under the horses. Everyone who walked by them, walked around the horses. What a great day that was</p>', 5);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (122, '06', 2, '', '<p>Just another wall of the shopping center. The whole theme was the gold rush days.</p>', 6);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (123, '07', 2, '', '<p>Do you need to hide a washer and dryer? Do you have an ugly closet? My client wanted to do just that. These are two folding doors that go to her laundry area. See the key hanging on the door? That is the knob to open it.</p>', 7);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (124, '08', 2, '', '<p>&nbsp;</p>', 8);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (125, '09', 2, '', '<p>&nbsp;</p>', 9);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (126, '10', 2, '', '<p>&nbsp;</p>', 10);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (127, '12', 2, 'Boston\'s Take Out', '<p>This piece is from a restaurant called Boston\'s Gourmet Pizza in Gilbert.  \r\n1026 S.l Gilbert Rd. (480)813-9223 These are all on chalkboards done with an oil based pastel. The colors are very vibrant. And the food is deeeelicious!!!</p>', 12);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (128, '13', 2, 'Boston\'s Lunch Special', '<p>This piece is from a restaurant called Boston\'s Gourmet Pizza in Gilbert.  \r\n1026 S.l Gilbert Rd. (480)813-9223 These are all on chalkboards done with an oil based pastel. The colors are very vibrant. And the food is deeeelicious!!!</p>', 13);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (129, '14', 2, 'Boston\'s Kids Sunday Meal', '<p>This piece is from a restaurant called Boston\'s Gourmet Pizza in Gilbert.  \r\n1026 S.l Gilbert Rd. (480)813-9223 These are all on chalkboards done with an oil based pastel. The colors are very vibrant. And the food is deeeelicious!!!</p>', 14);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (130, '15', 2, 'Boston\'s Happy Hour', '<p>This piece is from a restaurant called Boston\'s Gourmet Pizza in Gilbert.  \r\n1026 S.l Gilbert Rd. (480)813-9223 These are all on chalkboards done with an oil based pastel. The colors are very vibrant. And the food is deeeelicious!!!</p>', 15);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (131, '16', 2, 'Boston\'s Entrance', '<p>This piece is from a restaurant called Boston\'s Gourmet Pizza in Gilbert.  \r\n1026 S.l Gilbert Rd. (480)813-9223 These are all on chalkboards done with an oil based pastel. The colors are very vibrant. And the food is deeeelicious!!!</p>', 16);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (132, '19', 2, 'Before and after in a commercial office lobby area.', '<p>Here, I have incorporated the surrounding environment and architecture.  The rocks are the same as the outside of the building.  Also, the curved doorway is the same as the outside entryway.</p>', 19);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (133, '27', 2, '', '<p>This is an under water mural in a pediatrician\'s office.  The children love it.</p>', 27);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (134, '30', 2, '', '<p>Using a chalk board as a way for a restaurant to display their menu is unique and classic at the same time.  I have done this process for several restaurants in the Arizona area. </p>', 30);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (135, '01', 4, '', '<p>&nbsp;</p>', 1);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (136, '02', 4, '', '<p>&nbsp;</p>', 2);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (137, '03', 4, '', '<p>&nbsp;</p>', 3);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (138, '04', 4, '', '<p>This client needed to have this room done by Monday. She called me on Thursday night. She had an argument with another artist and fired her. We had to repaint the room and redo the walls and ceiling. I got the job done and she was delighted.</p>', 4);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (139, '05', 4, '', '<p>&nbsp;</p>', 5);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (140, '06', 4, '', '<p>&nbsp;</p>', 6);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (141, '07', 4, '', '<p>&nbsp;</p>', 7);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (142, '08', 4, '', '<p>&nbsp;</p>', 8);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (143, '09', 4, '', '<p>&nbsp;</p>', 9);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (144, '10', 4, '', '<p>&nbsp;</p>', 10);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (145, '11', 4, '', '<p>&nbsp;</p>', 11);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (146, '12', 4, 'Monkey swinging in a tree', '<p>Monkey swinging in a tree<br/>I can see him, but he won\'t see me.</p>', 12);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (147, '15', 1, '', '<p></p>', 15);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (148, '20', 1, '', '', 20);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (149, '93', 1, '', 'She wanted to feel the relaxing mood of the ocean.', 93);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (150, '154', 1, '', '<p>The wall decor is the motif from their throw rug.</p>', 154);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (151, '184', 1, '', '', 184);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (152, '185', 1, 'The Superstition Mountains', 'This is the superstition mountains that my client hikes often.  To the far right is Weaver\'s Needle that was very important to add to the mural.  She also has many horses to display and they worked very well placing them within the mural.\n', 185);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (153, '186', 1, 'It\'s All Good', '<p>This is of a wall I enhanced with brick and painted her \nhusband\'s favorite \"IT\'S ALL GOOD.\"   She has alot of wrought iron and \nwe wanted a special look.  They too have horses and we wanted to keep the theme.  The door to the right is just an old wooden door that was very ugly.  It goes to the garage.  Since she has all her doors wrought iron with glass, I copied one and made the door look like the other doors. </p><p>\nThe next image is of her REAL wrought iron door that goes to the yard.</p>', 186);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (154, '188', 1, 'The island of Arizona', 'This is Joyce\'s patio.  Now they have a beach in Arizona.', 188);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (155, '192', 1, 'Cat Village', 'Nothings to good for a couple spoiled cat\'s.\nIt all started because of that big box on the wall.  It is her ironing board and we were trying to hide it.  Also, what to do with the cat door.  I thought of a perfect outhouse.\n', 192);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (156, '197', 1, '', 'We may live in Arizona, but, we can still have our beaches near by.', 197);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (157, '200', 1, 'Garage Floor', 'This is a garage floor I stained.  Talk about gorgeous for a garage.\n', 200);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (158, '203', 1, 'Favorite Spot', 'Before and after of a village in Portafino where my client vacationed.  ', 203);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (161, '208', 1, '', '', 208);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (160, '207', 1, '', '', 207);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (162, '31', 2, 'Pretty Feathers', 'Pretty Feathers Bird Store - with detail of birds', 31);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (163, '211', 1, 'A Little Boy\'s Dream', 'He wants to be a fireman when he grows up.  He was very particular about each wall and what he wanted on them.', 209);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (164, '216', 3, 'Dog Portraits', 'These are portraits of dogs that were commissioned', 214);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (165, '15', 4, 'A Little Boy\'s Dream', 'He wants to be a fireman when he grows up.  He was very particular about each wall and what he wanted on them.', 13);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (166, '18', 4, '', 'This room belongs to another little child with dreams for the future.  I think she is also hoping daddy buys at least one of them for her birthday.  Which one will it be?  Molly, Chrystal or Joker?', 14);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (167, '214', 1, '', 'It started out with the Amolfi coast.  Then, found a picture of the Greek Monastery here in Arizona.  She wanted the cross on top. Then we added the tower and he took some pictures of the birds in Mexico.  Off to the side of the fountain is their precious dog that couldn\'t make the trip.  So, we brought her into the picture.  Sweet Honey is with them again. <br> \"I love to do these murals that have so much personal love and memories in them.\"', 210);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (168, '217', 3, 'Self Portrait with Lilly', '', 215);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (169, '215', 1, '', '', 211);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (170, '29', 5, 'Surfside', '', 29);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (171, '30', 5, '', '', 30);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (172, '31', 5, '', '', 31);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (173, '32', 5, '', '', 32);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (174, '33', 5, '', '', 33);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (175, '34', 5, '', '', 34);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (176, '35', 5, '\"Superstition Sunset\"', '', 35);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (177, '36', 5, '', '', 36);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (178, '37', 5, '', '', 37);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (180, '38', 5, '\"Bed And Breakfast\"', '', 39);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (181, '39', 5, '\"Morning Medow\"', '', 40);
INSERT INTO item (`id`, `name`, `page`, `title`, `description`, `sort_order`) VALUES (182, 'Peaceful Walk', 5, '\"Peaceful Walk\"', '', 41);


#
# TABLE STRUCTURE FOR: page
#

DROP TABLE IF EXISTS page;

CREATE TABLE `page` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(55) NOT NULL DEFAULT '',
  `page` varchar(55) NOT NULL DEFAULT '',
  `sort_order` int(11) NOT NULL DEFAULT '0',
  `additional_info` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

INSERT INTO page (`id`, `name`, `page`, `sort_order`, `additional_info`) VALUES (1, 'Residential', 'residential', 1, NULL);
INSERT INTO page (`id`, `name`, `page`, `sort_order`, `additional_info`) VALUES (2, 'Commercial', 'commercial', 2, NULL);
INSERT INTO page (`id`, `name`, `page`, `sort_order`, `additional_info`) VALUES (3, 'Odds and Ends', 'odds_and_ends', 3, NULL);
INSERT INTO page (`id`, `name`, `page`, `sort_order`, `additional_info`) VALUES (4, 'Children\'s Rooms', 'childrens_rooms', 4, NULL);
INSERT INTO page (`id`, `name`, `page`, `sort_order`, `additional_info`) VALUES (5, 'Art To Purchase', 'art_to_purchase', 5, NULL);


#
# TABLE STRUCTURE FOR: users
#

DROP TABLE IF EXISTS users;

CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(10) NOT NULL,
  `first_name` varchar(25) NOT NULL DEFAULT '',
  `last_name` varchar(25) NOT NULL DEFAULT '',
  `email_address` varchar(128) NOT NULL DEFAULT '',
  `password` varchar(32) NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO users (`id`, `username`, `first_name`, `last_name`, `email_address`, `password`, `date_created`) VALUES (1, 'robert', 'Robert', 'Milanowski', 'robert@rjmchicago.com', '940d1f6867b1944b766b1372e50b4b7f', '0000-00-00 00:00:00');


